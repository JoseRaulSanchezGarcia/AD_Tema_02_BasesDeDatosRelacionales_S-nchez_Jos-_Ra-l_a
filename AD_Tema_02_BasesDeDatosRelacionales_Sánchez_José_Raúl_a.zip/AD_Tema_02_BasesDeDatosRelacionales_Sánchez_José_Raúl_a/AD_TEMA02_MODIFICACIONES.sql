--                      JOS� RA�L S�NCHEZ GARC�A
CREATE OR REPLACE TRIGGER tr_Examenes_Upd
AFTER UPDATE ON EXAMENES
FOR EACH ROW
DECLARE
    xCodAlu MATRICULAS.CCODALU%TYPE;
    xCodCur MATRICULAS.CCODCURSO%TYPE;
    xMedia MATRICULAS.NNOTAMEDIA%TYPE;
    xAux EXAMENES.NNOTAEXAM%TYPE;
    xNumExa CURSOS.NNUMEXA%TYPE;
BEGIN
    xCodAlu := :NEW.CCODALU;
    xCodCur := :NEW.CCODCURSO;
    xAux := :NEW.NNOTAEXAM - :OLD.NNOTAEXAM;
    SELECT NNOTAMEDIA INTO xMedia FROM MATRICULAS WHERE CCODALU = xCodAlu AND CCODCURSO = xCodCur;
    SELECT NNUMEXA INTO xNumExa FROM CURSOS WHERE CCODCURSO = xCodCur;
    xMedia := xMedia + (xAux / xNumExa);
    UPDATE MATRICULAS SET NNOTAMEDIA = xMedia WHERE CCODALU = xCodAlu AND CCODCURSO = xCodCur;   
END;

---------------------------------------------------------------------------------------

CREATE OR REPLACE PROCEDURE sp_AltaMatricula (xcCodAlu VARCHAR2, xcCodCurso VARCHAR2, 
xError OUT NUMBER) IS 
    xNumExamenes CURSOS.NNUMEXA%TYPE;
BEGIN
    --Creo el registro de la tabla matriculas
    INSERT INTO MATRICULAS VALUES(xcCodAlu,xcCodCurso,0);
    
    --Obtengo el n� de registros que se tendr�n que crear en la tabla examenes
    SELECT NNUMEXA INTO xNumExamenes FROM CURSOS WHERE CCODCURSO = xcCodCurso;
    --Creo los registros adecuados
    FOR examen IN 1..xNumExamenes LOOP
        INSERT INTO EXAMENES VALUES (xcCodAlu,xcCodCurso,examen,NULL,0);
    END LOOP;
    --Si llega hasta aqu� se ha ejecutado todo correctamente
    xError := 0;
EXCEPTION
    --Si ya existe una matricula para ese alumno y ese curso, devuelvo -1
    WHEN DUP_VAL_ON_INDEX THEN xError := -1;
    --Si se produce otro tipo de excepci�n devuelvo -2
    WHEN OTHERS THEN xError := -2;
END;

---------------------------------------------------------------------------------------




--Pruebas
SELECT * FROM ALUMNOS;
INSERT INTO ALUMNOS VALUES ('001','Antonio');
INSERT INTO ALUMNOS VALUES ('002','Maria');

SELECT * FROM CURSOS;
INSERT INTO CURSOS VALUES ('I001','Ingles Basico',5);
INSERT INTO CURSOS VALUES ('I002','Ingles Intermedio',8);
INSERT INTO CURSOS VALUES ('I003','Ingles Avanzado',10);
INSERT INTO CURSOS VALUES ('F001','Frances Basico',3);
INSERT INTO CURSOS VALUES ('C002','Chino Intermedio',9);

SELECT * FROM EXAMENES;
SELECT * FROM MATRICULAS;
UPDATE EXAMENES SET nnotaexam = 8 WHERE nnumexam = 1;
--Registros de Antonio -> 001
SET SERVEROUTPUT ON;
DECLARE
    xError NUMBER := 9;
BEGIN
    sp_AltaMatricula('001','I001',xError);
    DBMS_OUTPUT.PUT_LINE('C�digo de error: ' || xError);
END;
--Registros de Maria -> 002
SET SERVEROUTPUT ON;
DECLARE
    xError NUMBER := 9;
BEGIN
    sp_AltaMatricula('002','C002',xError);
    DBMS_OUTPUT.PUT_LINE('C�digo de error: ' || xError);
END;
commit;
SELECT * FROM MATRICULAS;
delete examenes;
delete matriculas;

DESCRIBE ALUMNOS;
DESCRIBE CURSOS;
DESCRIBE EXAMENES;
DESCRIBE MATRICULAS;