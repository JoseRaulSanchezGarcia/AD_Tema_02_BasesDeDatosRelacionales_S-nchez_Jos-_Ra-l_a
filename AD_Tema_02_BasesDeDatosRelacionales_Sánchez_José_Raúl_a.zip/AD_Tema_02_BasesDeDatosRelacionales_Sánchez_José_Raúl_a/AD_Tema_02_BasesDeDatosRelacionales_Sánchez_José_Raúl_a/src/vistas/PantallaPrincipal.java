package vistas;

import controladores.CtrlAdminJson;
import controladores.CtrlAdminXml;
import controladores.CtrlConexion;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelos.Alumno;
import modelos.Curso;
import modelos.Matricula;
import modelos.Examen;
import modelos.Matriculado;

/**
 *
 * @author José Raúl Sánchez García
 */
public class PantallaPrincipal extends javax.swing.JFrame {
    //Declaración de variables
    private final CtrlConexion controlarCon = new CtrlConexion();
    private final boolean estaConectada = this.iniciarConexion();
    private DefaultTableModel dtmAlumnos;
    private ArrayList<Alumno> listaAlumnos;
    private DefaultTableModel dtmCursos;
    private ArrayList<Curso> listaCursos;
    private ArrayList<Matricula> listaMatriculas;
    private DefaultTableModel dtmMatriculas;
    private ArrayList<Examen> listaExamenes;
    private DefaultTableModel dtmExamenes;
    private ArrayList<Matriculado> listaMatriculados;
    private final CtrlAdminXml controlarXml = new CtrlAdminXml();
    private final CtrlAdminJson controlarJson = new CtrlAdminJson();
    
    
    //---------------------------------------------------------------------------
    public PantallaPrincipal() {
        initComponents();
        this.bActualizar.setVisible(false);
        this.bListadoMatri.setVisible(false);
        this.bBoletinJson.setVisible(false);
        this.setLocationRelativeTo(null);
        this.anadirAlumnos();
        this.anadirCursos();
        if(this.hayMatriculas()){
            this.mostrarDatosMatriculados();
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabAlumnos = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabCursos = new javax.swing.JTable();
        bMatricular = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabMatriculas = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        tabExamenes = new javax.swing.JTable();
        labFechaExamen = new javax.swing.JLabel();
        labNota = new javax.swing.JLabel();
        txtFechaExamen = new javax.swing.JTextField();
        txtNota = new javax.swing.JTextField();
        bActualizar = new javax.swing.JButton();
        bBoletinJson = new javax.swing.JButton();
        bListadoMatri = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tabAlumnos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Código Alumno", "Nombre"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabAlumnos);

        tabCursos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Código Curso", "Nombre Curso", "Nº Exámenes"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tabCursos);

        bMatricular.setText("Matricular Alumno en Curso");
        bMatricular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bMatricularActionPerformed(evt);
            }
        });

        tabMatriculas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código Alumno", "Nombre Alumno", "Código Curso", "Nombre Curso", "Nota Media"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabMatriculas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabMatriculasMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tabMatriculas);

        tabExamenes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Número Examen", "Fecha Examen", "Nota"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabExamenes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabExamenesMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tabExamenes);

        labFechaExamen.setText("Fecha Examen");

        labNota.setText("Nota");

        bActualizar.setText("Actualizar");
        bActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bActualizarActionPerformed(evt);
            }
        });

        bBoletinJson.setText("Boletin JSON");
        bBoletinJson.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBoletinJsonActionPerformed(evt);
            }
        });

        bListadoMatri.setText("Listado Matricula XML");
        bListadoMatri.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bListadoMatriActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(bBoletinJson, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(54, 54, 54)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(labFechaExamen, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                                    .addComponent(labNota, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(bActualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtNota)
                                    .addComponent(txtFechaExamen))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(bListadoMatri, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(15, 15, 15))
            .addGroup(layout.createSequentialGroup()
                .addGap(212, 212, 212)
                .addComponent(bMatricular)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(bMatricular)
                .addGap(34, 34, 34)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labFechaExamen)
                            .addComponent(txtFechaExamen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labNota)
                            .addComponent(txtNota, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(bActualizar)
                        .addGap(27, 27, 27)
                        .addComponent(bBoletinJson)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bListadoMatri)))
                .addGap(33, 33, 33))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bMatricularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMatricularActionPerformed
        //Compruebo que haya un alumno y un curso seleccionados
        int filaAlu = this.tabAlumnos.getSelectedRow();
        int filaCur = this.tabCursos.getSelectedRow();
        if (filaAlu != -1 && filaCur != -1) {
            //Consigo los datos que me interesan para ejecutar el procedimiento
            String codAlu = (String) this.dtmAlumnos.getValueAt(filaAlu, 0);
            String codCur = (String) this.dtmCursos.getValueAt(filaCur, 0);
            int error = this.controlarCon.matricularAlumno(codAlu, codCur);
            switch (error) {
                case 0:
                    String nomAlu = (String) this.dtmAlumnos.getValueAt(filaAlu, 1);
                    String nomCur = (String) this.dtmCursos.getValueAt(filaCur, 1);
                    this.listaMatriculas = this.controlarCon.getMatriculas();
                    Matricula m = new Matricula(codAlu, codCur, 0);
                    if (this.listaMatriculas != null && !this.listaMatriculas.isEmpty()) {
                        m = this.listaMatriculas.get(this.listaMatriculas.indexOf(m));
                    }
                    double notaMedia = m.getNotaMedia();
                    Object[] fila = new Object[5];
                    fila[0] = codAlu;
                    fila[1] = nomAlu;
                    fila[2] = codCur;
                    fila[3] = nomCur;
                    fila[4] = notaMedia;
                    this.dtmMatriculas = (DefaultTableModel) this.tabMatriculas.getModel();
                    this.dtmMatriculas.addRow(fila);
                    break;
                case -1:
                    JOptionPane.showMessageDialog(null, "Un alumno "
                            + "no puede matricularse dos veces en el mismo curso.");
                    break;
                case -2:
                    JOptionPane.showMessageDialog(null, "Ocurrió "
                            + "un error inesperado.");
                    break;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Debe seleccionar "
                    + "un alumno y un curso.");
        }
    }//GEN-LAST:event_bMatricularActionPerformed

    private void tabMatriculasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabMatriculasMouseClicked
        int filaSeleccionada = this.tabMatriculas.getSelectedRow();
        String codAlu = (String) this.dtmMatriculas.getValueAt(filaSeleccionada, 0);
        String codCur = (String) this.dtmMatriculas.getValueAt(filaSeleccionada, 2);
        this.listaExamenes = this.controlarCon.getExamenes(codAlu, codCur);
        if (this.listaExamenes != null && !this.listaExamenes.isEmpty()) {
            this.dtmExamenes = (DefaultTableModel) this.tabExamenes.getModel();
            this.dtmExamenes.setRowCount(0);
            Object[] fila = new Object[3];
            for (Examen e : this.listaExamenes) {
                fila[0] = e.getNumExa();
                fila[1] = e.getFechaExam();
                fila[2] = e.getNotaExam();
                this.dtmExamenes.addRow(fila);
                this.bActualizar.setVisible(true);
            }
            this.bBoletinJson.setVisible(true);
        }
    }//GEN-LAST:event_tabMatriculasMouseClicked

    private void tabExamenesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabExamenesMouseClicked
        int fila = this.tabExamenes.getSelectedRow();
        String fecha = (String) this.dtmExamenes.getValueAt(fila, 1);
        double nota = (double) this.dtmExamenes.getValueAt(fila, 2);
        this.txtFechaExamen.setText(fecha);
        this.txtNota.setText(String.valueOf(nota));
    }//GEN-LAST:event_tabExamenesMouseClicked

    private void bActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bActualizarActionPerformed
        if (this.tabExamenes.getSelectedRow() != -1) {
            String fecha = this.txtFechaExamen.getText();
            String textoNota = this.txtNota.getText();
            if(textoNota.isEmpty()){
                textoNota = "0";
            }
            double nota = Double.parseDouble(textoNota);
            String codAlu = (String) this.dtmMatriculas.getValueAt(this.tabMatriculas.getSelectedRow(), 0);
            String codCurso = (String) this.dtmMatriculas.getValueAt(this.tabMatriculas.getSelectedRow(), 2);
            double numExam = (double) this.dtmExamenes.getValueAt(this.tabExamenes.getSelectedRow(), 0);
            //JOptionPane.showMessageDialog(null, "NumExam " + numExam);
            int nfa = this.controlarCon.actualizarNota(fecha, nota, codAlu, codCurso, numExam);
            //Si se ha actualizado el registro, actualizo los datos de las tablas
            if(nfa > 0){
                //Recojo la información actualizada de la tabla Examenes
                this.listaExamenes = this.controlarCon.getExamenes();
                int filaSeleccionada = this.tabExamenes.getSelectedRow();
                this.dtmExamenes.setValueAt(fecha, filaSeleccionada, 1);
                this.dtmExamenes.setValueAt(nota, filaSeleccionada, 2);
                //Recojo la información actualizada de la tabla Matriculas
                this.listaMatriculas = this.controlarCon.getMatriculas();
                Matricula m = new Matricula(codAlu,codCurso);
                m = this.listaMatriculas.get(this.listaMatriculas.indexOf(m));
                double notaMedia = m.getNotaMedia();
                filaSeleccionada = this.tabMatriculas.getSelectedRow();
                this.dtmMatriculas.setValueAt(notaMedia, filaSeleccionada, 4);
            }
        }else{
            JOptionPane.showMessageDialog(null, "Debe seleccionar un registro en la tabla Exámenes");
        }
    }//GEN-LAST:event_bActualizarActionPerformed

    private void bListadoMatriActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bListadoMatriActionPerformed
        //NOTA: el texto saldrá sin formato
        if(this.controlarXml.crearFicheroXML(this.listaMatriculados)){
            JOptionPane.showMessageDialog(null, "El fichero se ha "
                    + "generado correctamente.");
        }else{
            JOptionPane.showMessageDialog(null, "No ha sido "
                    + "posible generar el fichero.");
        }
        
    }//GEN-LAST:event_bListadoMatriActionPerformed

    private void bBoletinJsonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBoletinJsonActionPerformed
        if(this.controlarJson.crearFicheroJson(this.listaExamenes)){
            JOptionPane.showMessageDialog(null, "El boletín se ha "
                    + "generado correctamente.");
        }else{
            JOptionPane.showMessageDialog(null, "No ha sido "
                    + "posible generar el boletín.");
        }
    }//GEN-LAST:event_bBoletinJsonActionPerformed
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PantallaPrincipal().setVisible(true);
            }
        });
    }
    
    //Métodos auxiliares
    //Este método sirve para agregar los alumnos del esquema a la tabla tabAlumnos
    private void anadirAlumnos() {
        this.dtmAlumnos = (DefaultTableModel) this.tabAlumnos.getModel();
        this.dtmAlumnos.setRowCount(0);
        if (this.estaConectada) {
            this.listaAlumnos = controlarCon.getAlumnos();
            if (!this.listaAlumnos.isEmpty()) {
                for (Alumno a : this.listaAlumnos) {
                    Object[] fila = new Object[2];
                    fila[0] = a.getCodigo();
                    fila[1] = a.getNombre();
                    this.dtmAlumnos.addRow(fila);
                }

            }
        }
    }

    //Este método sirve para agregar los cursos del esquema a la tabla tabCursos
    private void anadirCursos() {
        this.dtmCursos = (DefaultTableModel) this.tabCursos.getModel();
        this.dtmCursos.setRowCount(0);
        if (this.estaConectada) {
            this.listaCursos = this.controlarCon.getCursos();
            if (!this.listaCursos.isEmpty()) {
                for (Curso c : this.listaCursos) {
                    Object[] fila = new Object[3];
                    fila[0] = c.getCodigo();
                    fila[1] = c.getNombre();
                    fila[2] = c.getNumExamenes();
                    this.dtmCursos.addRow(fila);
                }
            }
        }
    }

    //Este método sirve para comprobar si hay alumnos matriculados en algún curso
    private boolean hayMatriculas() {
        boolean hayMatriculas = false;
        this.listaMatriculas = this.controlarCon.getMatriculas();
        if (this.listaMatriculas != null && !this.listaMatriculas.isEmpty()) {
            hayMatriculas = true;
        }
        return hayMatriculas;
    }

    //Muestro los nombres de los alumnos y cursos asociados a las matrículas existentes en tabMatriculas
    private void mostrarDatosMatriculados() {
        this.listaAlumnos = this.controlarCon.getAlumnos();
        this.listaCursos = this.controlarCon.getCursos();
        this.listaMatriculados = new ArrayList<>();
        //No hace falta comprobar que haya matrículas, si se ejecuta este método es porque las hay
        for (Matricula m : this.listaMatriculas) {
            String codAlu = m.getCodigoAlu();
            String codCur = m.getCodigoCur();
            Alumno a = this.listaAlumnos.get(this.listaAlumnos.indexOf(new Alumno(codAlu, "")));
            Curso c = this.listaCursos.get(this.listaCursos.indexOf(new Curso(codCur, "", 0)));
            String nomAlu = a.getNombre();
            String nomCur = c.getNombre();
            Object[] fila = new Object[5];
            fila[0] = codAlu;
            fila[1] = nomAlu;
            fila[2] = codCur;
            fila[3] = nomCur;
            fila[4] = m.getNotaMedia();
            Matriculado matriculado = new Matriculado(codAlu,nomAlu,codCur,nomCur,m.getNotaMedia());
            this.listaMatriculados.add(matriculado);
            this.dtmMatriculas = (DefaultTableModel) this.tabMatriculas.getModel();
            this.dtmMatriculas.addRow(fila);
        }
        this.bListadoMatri.setVisible(true);
    }

    //Este método sirve para iniciar la conexión a la base de datos
    private boolean iniciarConexion() {
        boolean estaIniciada = false;
        if (this.controlarCon.conectar() != null) {
            estaIniciada = true;
        }
        return estaIniciada;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bActualizar;
    private javax.swing.JButton bBoletinJson;
    private javax.swing.JButton bListadoMatri;
    private javax.swing.JButton bMatricular;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel labFechaExamen;
    private javax.swing.JLabel labNota;
    private javax.swing.JTable tabAlumnos;
    private javax.swing.JTable tabCursos;
    private javax.swing.JTable tabExamenes;
    private javax.swing.JTable tabMatriculas;
    private javax.swing.JTextField txtFechaExamen;
    private javax.swing.JTextField txtNota;
    // End of variables declaration//GEN-END:variables
}
