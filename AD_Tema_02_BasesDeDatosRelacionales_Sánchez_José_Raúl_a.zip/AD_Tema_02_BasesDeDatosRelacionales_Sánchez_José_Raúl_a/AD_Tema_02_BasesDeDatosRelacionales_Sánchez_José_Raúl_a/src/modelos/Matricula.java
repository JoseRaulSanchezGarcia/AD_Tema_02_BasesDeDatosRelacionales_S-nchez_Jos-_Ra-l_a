package modelos;

import java.util.Objects;

/**
 *
 * @author José Raúl Sánchez García
 */
public class Matricula {
    //Atributos
    private String codigoAlu;
    private String codigoCur;
    private double notaMedia;
    //--------------------------------------------------------------------------
    //Métodos
    //Constructor por defecto
    public Matricula() {
    }
    //Constructor por parámetros
    public Matricula(String codigoAlu, String codigoCur, double notaMedia) {
        this.codigoAlu = codigoAlu;
        this.codigoCur = codigoCur;
        this.notaMedia = notaMedia;
    }
    public Matricula(String codigoAlu, String codigoCur){
        this.codigoAlu = codigoAlu;
        this.codigoCur = codigoCur;
    }
    
    
    //Getters and setters
    public String getCodigoAlu() {
        return codigoAlu;
    }

    public void setCodigoAlu(String codigoAlu) {
        this.codigoAlu = codigoAlu;
    }

    public String getCodigoCur() {
        return codigoCur;
    }

    public void setCodigoCur(String codigoCur) {
        this.codigoCur = codigoCur;
    }

    public double getNotaMedia() {
        return notaMedia;
    }

    public void setNotaMedia(double notaMedia) {
        this.notaMedia = notaMedia;
    }
    
    @Override
    public String toString() {
        return "CodigoAlu: " + codigoAlu + " CodigoCur: " + codigoCur + " NotaMedia: " + notaMedia;
    }
    
    @Override
    public boolean equals(Object o) {
        boolean esIgual = false;
        if(o instanceof Matricula){
            Matricula m = (Matricula) o;
            if(this.codigoAlu.equals(m.getCodigoAlu()) && this.codigoCur.equals(m.getCodigoCur())){
                esIgual = true;
            }
        }
        return esIgual;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.codigoAlu);
        hash = 29 * hash + Objects.hashCode(this.codigoCur);
        return hash;
    }
    
    
}
