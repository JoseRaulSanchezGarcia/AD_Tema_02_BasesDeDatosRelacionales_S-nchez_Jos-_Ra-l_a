package modelos;

import java.util.Objects;

/**
 *
 * @author José Raúl Sánchez García
 */
public class Curso {
    //Atributos
    private String codigo;
    private String nombre;
    private Integer numExamenes;
    //--------------------------------------------------------------------------
    //Métodos
    //Constructor por defecto
    public Curso() {
    }
    //Constructor por parámetros
    public Curso(String codigo, String nombre, Integer numExamenes) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.numExamenes = numExamenes;
    }
    
    
    //Getters and setters
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getNumExamenes() {
        return numExamenes;
    }

    public void setNumExamenes(Integer numExamenes) {
        this.numExamenes = numExamenes;
    }

    @Override
    public String toString() {
        return "Codigo: " + this.codigo + " Nombre: " + this.nombre + " NumExamenes: " + this.numExamenes;
    }
    
    @Override
    public boolean equals(Object o) {
        boolean esIgual = false;
        if(o instanceof Curso){
            Curso c = (Curso) o;
            if(this.codigo.equals(c.getCodigo())){
                esIgual = true;
            }
        }
        return esIgual;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 17 * hash + Objects.hashCode(this.codigo);
        return hash;
    }
    
    
}
