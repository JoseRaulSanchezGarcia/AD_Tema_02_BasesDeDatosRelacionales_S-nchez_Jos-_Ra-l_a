package modelos;

import java.util.Objects;

/**
 *
 * @author José Raúl Sánchez García
 */
public class Examen {
    //Atributos
    private String codigoAlu;
    private String codigoCur;
    private Double numExa;
    private String fechaExam;
    private Double notaExam;
    //--------------------------------------------------------------------------
    //Métodos
    //Constructor por defecto
    public Examen() {
    }
    //Constructores por parámetros
    public Examen(String codigoAlu, String codigoCur, Double numExa, String fechaExam, Double notaExam) {
        this.codigoAlu = codigoAlu;
        this.codigoCur = codigoCur;
        this.numExa = numExa;
        this.fechaExam = fechaExam;
        this.notaExam = notaExam;
    }
    public Examen(Double numExa, String fechaExam, Double notaExam) {
        this.numExa = numExa;
        this.fechaExam = fechaExam;
        this.notaExam = notaExam;
    }
    
    
    //Getters and setters
    public String getCodigoAlu() {
        return codigoAlu;
    }

    public void setCodigoAlu(String codigoAlu) {
        this.codigoAlu = codigoAlu;
    }

    public String getCodigoCur() {
        return codigoCur;
    }

    public void setCodigoCur(String codigoCur) {
        this.codigoCur = codigoCur;
    }

    public Double getNumExa() {
        return numExa;
    }

    public void setNumExa(Double numExa) {
        this.numExa = numExa;
    }

    public String getFechaExam() {
        String devuelto = "";
        if(this.fechaExam != null){
            devuelto = this.fechaExam;
        }
        return devuelto;
    }

    public void setFechaExam(String fechaExam) {
        this.fechaExam = fechaExam;
    }

    public Double getNotaExam() {
        return notaExam;
    }

    public void setNotaExam(Double notaExam) {
        this.notaExam = notaExam;
    }

    @Override
    public String toString() {
        return "CodigoAlu: " + codigoAlu + " CodigoCur: " + codigoCur + " NumExa: " + numExa + " FechaExam: " + fechaExam + " NotaExam: " + notaExam;
    }
    
    @Override
    public boolean equals(Object o) {
        boolean esIgual = false;
        if(o instanceof Examen){
            Examen e = (Examen) o;
            if(this.codigoAlu.equals(e.getCodigoAlu()) && this.codigoCur.equals(e.getCodigoCur())
                    && this.numExa.equals(e.getNumExa())){
                esIgual = true;
            }
        }
        return esIgual;
    }
    
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + Objects.hashCode(this.codigoAlu);
        hash = 89 * hash + Objects.hashCode(this.codigoCur);
        hash = 89 * hash + Objects.hashCode(this.numExa);
        return hash;
    }
}
