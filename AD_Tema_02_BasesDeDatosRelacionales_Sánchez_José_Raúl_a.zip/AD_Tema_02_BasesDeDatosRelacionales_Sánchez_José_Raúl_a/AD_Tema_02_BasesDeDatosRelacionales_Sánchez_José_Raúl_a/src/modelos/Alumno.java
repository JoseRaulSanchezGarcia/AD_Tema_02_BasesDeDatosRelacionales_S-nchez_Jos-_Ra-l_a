package modelos;

import java.util.Objects;

/**
 *
 * @author José Raúl Sánchez García
 */
public class Alumno {
    //Atributos
    private String codigo;
    private String nombre;
    //--------------------------------------------------------------------------
    //Métodos
    //Constructor por defecto
    public Alumno() {
    }
    //Constructor por parámetros
    public Alumno(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }
    
    
    //Getters and setters
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Codigo: " + this.codigo + " Nombre: " + this.nombre;
    }
    
    @Override
    public boolean equals(Object o) {
        boolean esIgual = false;
        if(o instanceof Alumno){
            Alumno a = (Alumno) o;
            if(this.codigo.equals(a.getCodigo())){
                esIgual = true;
            }
        }
        return esIgual;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 83 * hash + Objects.hashCode(this.codigo);
        return hash;
    }
    
}
