package controladores;
import java.io.File;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import modelos.Matriculado;
/**
 *
 * @author José Raúl Sánchez García
 */
public class CtrlAdminXml {
    //Atributos
    private DocumentBuilderFactory factory;
    private DocumentBuilder builder;
    private DOMImplementation implementation;
    private Document doc;
    private Source source;
    private Result result;
    private Transformer transformer;
    //--------------------------------------------------------------------------
    //Métodos
    //Constructor por defecto
    public CtrlAdminXml(){
        this.factory = DocumentBuilderFactory.newInstance();
        try {
            this.builder = this.factory.newDocumentBuilder();
            this.implementation = this.builder.getDOMImplementation();
            this.doc = this.implementation.createDocument(null, "matriculas", null);
            this.doc.setXmlVersion("1.0");
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(CtrlAdminXml.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public boolean crearFicheroXML(ArrayList<Matriculado> listaMatriculados){
        boolean seHaCreado = false;
        //Recorro la lista
        for(Matriculado m : listaMatriculados){
            //Creo las etiquetas necesarias
            Element alumno = this.doc.createElement("Alumno");
            Element nomAlu = this.doc.createElement("Nombre");
            Element codAlu = this.doc.createElement("Codigo");
            
            Element curso = this.doc.createElement("Curso");
            Element nomCur = this.doc.createElement("Nombre");
            Element codCur = this.doc.createElement("Codigo");
            Element nota = this.doc.createElement("Nota");
            Text textoEtiqueta = this.doc.createTextNode(m.getNombreAlumno());
            //Añado los datos a las etiquetas y creo la estructura
            nomAlu.appendChild(textoEtiqueta);
            alumno.appendChild(nomAlu);
            textoEtiqueta = this.doc.createTextNode(m.getCodigoAlumno());
            codAlu.appendChild(textoEtiqueta);
            alumno.appendChild(codAlu);
            
            textoEtiqueta = this.doc.createTextNode(m.getNombreCurso());
            nomCur.appendChild(textoEtiqueta);
            curso.appendChild(nomCur);
            textoEtiqueta = this.doc.createTextNode(m.getCodigoCurso());
            codCur.appendChild(textoEtiqueta);
            curso.appendChild(codCur);
            textoEtiqueta = this.doc.createTextNode(String.valueOf(m.getNotaMedia()));
            nota.appendChild(textoEtiqueta);
            curso.appendChild(nota);
            alumno.appendChild(curso);
            
            this.doc.getDocumentElement().appendChild(alumno);
            
        }
        try {
            //Aquí ya está creada toda la estructura, solo queda transformarla
            this.transformer = TransformerFactory.newInstance().newTransformer();
            this.source = new DOMSource(this.doc);
            this.result = new StreamResult(new File("matriculas.xml"));
            this.transformer.transform(this.source, this.result);
            seHaCreado = true;
        } catch (TransformerConfigurationException ex) {
            System.out.println("Error durante la creación del transformer");
        } catch (TransformerException ex) {
            System.out.println("Error durante la transformación del archivo");
        } finally{
            return seHaCreado;
        }
    }
    
}
