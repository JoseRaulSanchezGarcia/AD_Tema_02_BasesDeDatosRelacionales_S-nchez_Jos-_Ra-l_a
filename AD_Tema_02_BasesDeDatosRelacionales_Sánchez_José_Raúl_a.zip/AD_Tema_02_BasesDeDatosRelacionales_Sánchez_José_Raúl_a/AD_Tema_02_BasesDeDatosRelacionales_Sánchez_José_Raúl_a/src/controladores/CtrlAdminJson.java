package controladores;

import com.google.gson.Gson;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import modelos.Examen;

/**
 *
 * @author José Raúl Sánchez García
 */
public class CtrlAdminJson {
    //Atributos
    private Gson conversor;
    private String json;
    private ArrayList<Object> hola;
    //--------------------------------------------------------------------------
    //Métodos
    //Constructor por defecto
    public CtrlAdminJson() {
        this.conversor = new Gson();
        this.json = "";
    }
    
    
    public boolean crearFicheroJson(ArrayList<Examen> listaExamenes){
        boolean seHaCreado = false;
        BufferedWriter bw = null;
        try{
            bw = new BufferedWriter(new FileWriter(new File("boletínNotas.json")));
        } catch(IOException ex){}
        for(Examen e : listaExamenes){
            try {
                this.json = this.conversor.toJson(e);
                bw.write(this.json);
                bw.newLine();
                bw.newLine();
                seHaCreado = true;
            } catch (IOException ex) {}
        }
        try{
            bw.close();
        } catch(IOException ex){
        } finally{
            return seHaCreado;
        }
    }
    
}
