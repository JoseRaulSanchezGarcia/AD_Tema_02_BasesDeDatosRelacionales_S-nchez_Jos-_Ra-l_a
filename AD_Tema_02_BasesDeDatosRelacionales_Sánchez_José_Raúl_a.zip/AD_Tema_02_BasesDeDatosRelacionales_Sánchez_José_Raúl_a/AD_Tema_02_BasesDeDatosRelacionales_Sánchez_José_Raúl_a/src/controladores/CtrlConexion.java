package controladores;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import modelos.Alumno;
import modelos.Curso;
import modelos.Examen;
import modelos.Matricula;

/**
 *
 * @author José Raúl Sánchez García
 */
public class CtrlConexion {
    //Atributos
    private Connection con;
    private String ins;
    private Statement st;
    private ResultSet rs;
    private ArrayList<Alumno> listaAlumnos = new ArrayList<>();
    private ArrayList<Curso> listaCursos = new ArrayList<>();
    private ArrayList<Matricula> listaMatriculas = new ArrayList<>();
    private CallableStatement cs;
    private PreparedStatement ps;
    private ArrayList<Examen> listaExamenes = new ArrayList<>();
    //-------------------------------------------------------------------------------------------------------------------------------
    //Métodos
    //Constructor por defecto
    public Connection conectar(){
        try {
            this.con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "AD_TEMA02", "AD_TEMA02");
        } catch (SQLException ex) {
            this.con = null;
        }
        return this.con;
    }
    
    
    public ArrayList<Alumno> getAlumnos(){
        this.listaAlumnos.clear();
        try{
            if(this.estaAbierta()){
                this.ins = "SELECT * FROM ALUMNOS";
                this.st = this.con.createStatement();
                this.rs = this.st.executeQuery(this.ins);
                while(this.rs.next()){
                    this.listaAlumnos.add(new Alumno(this.rs.getString("CCODALU"),
                            this.rs.getString("CNOMALU")));
                }
            }
        } catch(SQLException ex){
        } finally{
            try {
                this.st.close();
                this.rs.close();
            } catch (SQLException ex) {
            } finally{ return this.listaAlumnos;}
        }
    }
    
    
    public ArrayList<Curso> getCursos(){
        this.listaCursos.clear();
        try {
            if(this.estaAbierta()){
               this.ins = "SELECT * FROM CURSOS";
               this.st = this.con.createStatement();
               this.rs = this.st.executeQuery(this.ins);
               while(rs.next()){
                   this.listaCursos.add(new Curso(this.rs.getString("CCODCURSO"),
                   this.rs.getString("CNOMCURSO"),
                   this.rs.getInt("NNUMEXA")));
               }
            }
        } catch (SQLException ex) {
        } finally{
            try{
                this.st.close();
                this.rs.close();
            } catch(SQLException ex){
                
            } finally{
                return this.listaCursos;
            }
        }
    }
    
    
    public ArrayList<Matricula> getMatriculas(){
        this.listaMatriculas.clear();
        try {
            if(this.estaAbierta()){
               this.ins = "SELECT * FROM MATRICULAS";
               this.st = this.con.createStatement();
               this.rs = this.st.executeQuery(this.ins);
               while(rs.next()){
                   this.listaMatriculas.add(new Matricula(this.rs.getString("CCODALU"),
                   this.rs.getString("CCODCURSO"),
                   this.rs.getInt("NNOTAMEDIA")));
               }
            }
        } catch (SQLException ex) {
        } finally{
            try{
                this.st.close();
                this.rs.close();
            } catch(SQLException ex){
                
            } finally{
                return this.listaMatriculas;
            }
        }
    }
    
    
    public int matricularAlumno(String codAlu, String codCur){
        int error = -2;
        //Preparo la llamada al procedimiento
        this.ins = "{call sp_AltaMatricula(?,?,?) }";
        try {
            if(this.estaAbierta()){
                this.cs = this.con.prepareCall(this.ins);
                //Le paso los parámetros de entrada
                this.cs.setString(1, codAlu);
                this.cs.setString(2, codCur);
                //Registro y obtengo el parámetro de salida
                this.cs.registerOutParameter(3, Types.INTEGER);
                this.cs.executeQuery();
                error = this.cs.getInt(3);
            }
        } catch (SQLException ex) {
        } finally {
            try {
                this.cs.close();
            } catch (SQLException ex) {
            } finally{return error;}
        }
    }
    
    
    public ArrayList<Examen> getExamenes(String codAlu, String codCur) {
        this.listaExamenes.clear();
        try {
            if (this.estaAbierta()) {
                this.ins = "SELECT NNUMEXAM, DFECEXAM, NNOTAEXAM FROM EXAMENES WHERE CCODALU = ? AND CCODCURSO = ?";
                this.ps = this.con.prepareStatement(this.ins);
                this.ps.setString(1, codAlu);
                this.ps.setString(2, codCur);
                this.rs = this.ps.executeQuery();
                while (this.rs.next()) {
                    Date dateAux = this.rs.getDate("DFECEXAM");
                    LocalDate ldAux = null;
                    DateTimeFormatter formato = null;
                    String fecha = "";
                    if(dateAux != null){
                        ldAux = dateAux.toLocalDate();
                        formato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                        fecha = ldAux.format(formato);
                    }
                    this.listaExamenes.add(new Examen(this.rs.getDouble("NNUMEXAM"),
                    fecha,
                    this.rs.getDouble("NNOTAEXAM")));
                }
            }
        } catch (SQLException ex) {
        } finally {
            try {
                this.ps.close();
                this.rs.close();
            } catch (SQLException ex) {
            } finally {
                //JOptionPane.showMessageDialog(null, "DEVUELVOOOOO");
                return this.listaExamenes;}
        }
    }
    
    
    public int actualizarNota(String fecha, double nota, String codAlu, String codCurso, double numExam){
        int nfa = 0;
        try{
            if(this.estaAbierta()){
                this.ins = "UPDATE EXAMENES SET DFECEXAM = ?, NNOTAEXAM = ? WHERE CCODALU = ? "
                        + "AND CCODCURSO = ? AND NNUMEXAM = ?";
                this.ps = this.con.prepareStatement(this.ins);
                this.ps.setString(1, fecha);
                this.ps.setDouble(2, nota);
                this.ps.setString(3, codAlu);
                this.ps.setString(4, codCurso);
                this.ps.setDouble(5, numExam);
                nfa = this.ps.executeUpdate();
            }
        } catch(SQLException ex){
        } finally{
            try {
                    this.ps.close();
                } catch (SQLException ex) {
                } finally{return nfa; }
        }
    }
    
    
    public ArrayList<Examen> getExamenes(){
        this.listaExamenes.clear();
        try {
            if(this.estaAbierta()){
               //JOptionPane.showMessageDialog(null, "ENTRA: ");
               this.ins = "SELECT * FROM EXAMENES";
               this.st = this.con.createStatement();
               this.rs = this.st.executeQuery(this.ins);
               while(rs.next()){
                   Date dateAux = this.rs.getDate("DFECEXAM");
                   LocalDate ldAux = null;
                   DateTimeFormatter formato = null;
                   String fecha = "";
                   if (dateAux != null) {
                       ldAux = dateAux.toLocalDate();
                       formato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                       fecha = ldAux.format(formato);
                   }
                    Examen e = new Examen(this.rs.getDouble("NNUMEXAM"),fecha,this.rs.getDouble("NNOTAEXAM"));
                    this.listaExamenes.add(e);
               }
            }
        } catch (SQLException ex) {
        } finally{
            try{
                this.st.close();
                this.rs.close();
            } catch(SQLException ex){
                
            } finally{
                return this.listaExamenes;
            }
        }
    }
    
    
    
    
    //-------------------------------------------------------------------------------------------------------------------------------
    //Métodos auxiliares
    //Este método sirve para comprobar que la conexión está abierta
    private boolean estaAbierta(){
        boolean estaAbierta = false;
        try {
            if(this.con != null && !this.con.isClosed()){
                estaAbierta = true;
            }
        } catch (SQLException ex) {
        } finally{
            return estaAbierta;
        }
    }
}
